* Project second part: bathymetric points for bathymetric model
- test_bathymetric.pts	capacity: 5, 10, 15

* Project second part: canopy points for canopy model
test_chm.pts   capacity: 5, 10, 15